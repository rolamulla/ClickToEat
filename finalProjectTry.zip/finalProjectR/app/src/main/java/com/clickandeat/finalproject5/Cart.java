package com.clickandeat.finalproject5;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.clickandeat.finalproject5.adapter.AllMenuAdapter;
import com.clickandeat.finalproject5.adapter.myCartAdapter;
import com.clickandeat.finalproject5.model.AllMenu;
import com.clickandeat.finalproject5.model.myCartModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class Cart extends AppCompatActivity {
    ImageView backImg, backImg1;

    Button buttonAddToCart;

    FirebaseFirestore db;
    FirebaseAuth auth;

    RecyclerView recyclerView;
    myCartAdapter myCartAdapter;
    List<myCartModel> cartModelList = new ArrayList<>();

    TextView overTotalAmount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);


        backImg = findViewById(R.id.backImg);
        backImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cart.super.onBackPressed();
            }
        });
        backImg1 = findViewById(R.id.backImg1);
        backImg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cart.super.onBackPressed();
            }
        });


        buttonAddToCart = findViewById(R.id.buttonAddToCart);
        buttonAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Cart.this, YarkaHome.class));            }
        });

        //db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();


        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);

        RecyclerView myCartRecyclerView = findViewById(R.id.recyclerview);

        myCartRecyclerView.setLayoutManager(linearLayoutManager);
        myCartAdapter = new myCartAdapter(this, cartModelList);
        myCartRecyclerView.setAdapter(myCartAdapter);

        String email = FirebaseAuth.getInstance().getCurrentUser().getEmail().replace(".", "_");

        FirebaseFirestore data = FirebaseFirestore.getInstance();

        overTotalAmount = findViewById(R.id.totalTxt);
//        LocalBroadcastManager.getInstance()
//                .registerReceiver(new IntentFilter("Total"));

        data.collection("AddToCart").document(auth.getCurrentUser().getUid())
                .collection("User").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                for (DocumentSnapshot documentSnapshot : task.getResult().getDocuments()) {
                    myCartModel item = documentSnapshot.toObject(myCartModel.class);

                    cartModelList.add(item);
                }
                myCartAdapter.notifyDataSetChanged();
            }

            public BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {

                    int totalBill = intent.getIntExtra("Total Amount",0);
                    overTotalAmount.setText("Total Bill"+totalBill+"₪");
                }
            };

            public void onCancelled(DatabaseError databaseError) {
            }
        });

    }




}