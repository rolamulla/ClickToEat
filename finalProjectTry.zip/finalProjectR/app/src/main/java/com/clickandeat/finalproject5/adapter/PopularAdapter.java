package com.clickandeat.finalproject5.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.clickandeat.finalproject5.FoodDetails;
import com.clickandeat.finalproject5.R;
import com.clickandeat.finalproject5.YarkaHome;
import com.clickandeat.finalproject5.model.Popular;
import com.clickandeat.finalproject5.model.homeCategory;
import com.clickandeat.finalproject5.viewAllActivity;

import java.util.List;

public class PopularAdapter extends RecyclerView.Adapter<PopularAdapter.PopularViewHolder> {

    private Context context;
    private List<Popular> popularList;


    public PopularAdapter(Context context, List<Popular> popularList) {
        this.context = context;
        this.popularList = popularList;
    }



    @NonNull
    @Override
    public PopularViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.popular_recycler_items, parent, false);
        return new PopularViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PopularAdapter.PopularViewHolder holder, @SuppressLint("RecyclerView") int position) {
        final Popular popular = popularList.get(position);
        //Toast.makeText(context,position+" ",Toast.LENGTH_LONG).show();

        //set values
        holder.popularName.setText(popular.getName());
        // holder.tvText.setText(post.getText());
        //  holder.popularName.setText(popularList.get(position).getName());
        Glide.with(context).load(popularList.get(position).getImage()).into(holder.popularImage);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, FoodDetails.class);
                i.putExtra("name", popularList.get(position).getName());
                i.putExtra("price", popularList.get(position).getPrice());
                i.putExtra("rating", popularList.get(position).getRating());
                i.putExtra("image", popularList.get(position).getImage());


                i.putExtra("note", popularList.get(position).getNote());
                i.putExtra("restaurant", popularList.get(position).getRestaurant());
                i.putExtra("category", popularList.get(position).getCategory());

                context.startActivity(i);
            }
        });

//        holder.itemView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(context, viewAllActivity.class);
//                intent.putExtra("type", popularList.get(position).getCategory());
//                context.startActivity(intent);
//            }
//        });

    }

    @Override
    public int getItemCount() {
        return popularList.size();
    }

    public  static class PopularViewHolder extends RecyclerView.ViewHolder{

        ImageView popularImage;
        TextView popularName;

        public PopularViewHolder(@NonNull View itemView) {
            super(itemView);

            popularImage = itemView.findViewById(R.id.popular_image);
            popularName = itemView.findViewById(R.id.popular_name);

        }
    }
}