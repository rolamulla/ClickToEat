package com.clickandeat.finalproject5;

import androidx.appcompat.app.AppCompatActivity;

public class AdminLog extends AppCompatActivity {
}
