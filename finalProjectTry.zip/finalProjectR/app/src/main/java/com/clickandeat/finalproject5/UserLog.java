package com.clickandeat.finalproject5;

import androidx.appcompat.app.AppCompatActivity;

public class UserLog extends AppCompatActivity {
}
