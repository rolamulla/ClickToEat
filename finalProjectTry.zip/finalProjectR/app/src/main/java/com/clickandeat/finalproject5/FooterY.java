package com.clickandeat.finalproject5;

import android.content.Intent;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.clickandeat.finalproject5.settings.Account;
import com.clickandeat.finalproject5.settings.Info;
import com.clickandeat.finalproject5.settings.SettingsActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class FooterY {

    FloatingActionButton homeBtn, profileBtn , settingsBtn ,favBtn ,cartBtn;
    private static FooterY instance = new FooterY();

    private FooterY(){}
    public static FooterY getInstance(){
        return instance;
    }
    protected void initFooter(final AppCompatActivity appCompatActivity) {

        homeBtn = appCompatActivity.findViewById(R.id.imageHome);
        profileBtn = appCompatActivity.findViewById(R.id.imageProfile);
        settingsBtn = appCompatActivity.findViewById(R.id.imageSettings);
        favBtn = appCompatActivity.findViewById(R.id.imageFavourite);
        cartBtn = appCompatActivity.findViewById(R.id.cartBtn);


        homeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appCompatActivity.startActivity(new Intent(appCompatActivity, YarkaHome.class));
            }
        });

        profileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appCompatActivity.startActivity(new Intent(appCompatActivity, Account.class));
            }
        });

        settingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appCompatActivity.startActivity(new Intent(appCompatActivity, SettingsActivity.class));
            }
        });

        favBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appCompatActivity.startActivity(new Intent(appCompatActivity, Info.class));
            }
        });

        cartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appCompatActivity.startActivity(new Intent(appCompatActivity, Cart.class));
            }
        });
    }
}