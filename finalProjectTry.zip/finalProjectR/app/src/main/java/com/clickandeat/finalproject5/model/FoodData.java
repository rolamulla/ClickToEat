
package com.clickandeat.finalproject5.model;

import java.util.List;

public class FoodData {

    //    @SerializedName("popular")
//    @Expose
    private List<Popular> popular;
    //    @SerializedName("recommended")
//    @Expose
    private List<Recommended> recommended;
    //    @SerializedName("allMenu")
//    @Expose
    private List<AllMenu> allMenu;

    public List<Popular> getPopular() {
        return popular;
    }

    public void setPopular(List<Popular> popular) {
        this.popular = popular;
    }

    public List<Recommended> getRecommended() {
        return recommended;
    }

    public void setRecommended(List<Recommended> recommended) {
        this.recommended = recommended;
    }

    public List<AllMenu> getAllMenu() {
        return allMenu;
    }

    public void setAllMenu(List<AllMenu> allMenu) {
        this.allMenu = allMenu;
    }
}