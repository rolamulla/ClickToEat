package com.clickandeat.finalproject5;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.clickandeat.finalproject5.adapter.viewAllAdapter;
import com.clickandeat.finalproject5.model.homeCategory;
import com.clickandeat.finalproject5.model.viewAll;
import com.clickandeat.finalproject5.settings.Account;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class viewAllActivity extends AppCompatActivity {


    FirebaseDatabase firebaseDatabase;
    RecyclerView recyclerView;
    viewAllAdapter viewAllAdapter;
    List <viewAll> viewAllList;
    FirebaseFirestore firestore;
    ImageView backImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all);

        backImg = findViewById(R.id.backImg);
        backImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewAllActivity.super.onBackPressed();
            }
        });

        firestore = FirebaseFirestore.getInstance();

        firebaseDatabase = FirebaseDatabase.getInstance();

        String category = getIntent().getStringExtra("category");

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();



        recyclerView = findViewById(R.id.view_all_category);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        viewAllList = new ArrayList<>();
        viewAllAdapter = new viewAllAdapter(this, viewAllList);

        recyclerView.setAdapter(viewAllAdapter);

        if ( category != null && category.equalsIgnoreCase("Meat")){
            firestore.collection("PopularYarka")
                    .whereEqualTo("category","Meat").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    if( task.isSuccessful()) {
                    for(DocumentSnapshot documentSnapshot :task.getResult().getDocuments()){
                        viewAll viewAll = documentSnapshot.toObject(viewAll.class);
                        viewAllList.add(viewAll);
                        viewAllAdapter.notifyDataSetChanged();
                    }}
                    else{
                        Toast.makeText(viewAllActivity.this,"Error"+task.getException(), Toast.LENGTH_SHORT).show();
                    }

                }
            });
//                @Override
//                public void onComplete(@NonNull Task<DataSnapshot> task) {
//                    if( task.isSuccessful()) {
//                        for (DataSnapshot document : task.getResult().getChildren()) {
//                            viewAll viewAll = document.getValue(viewAll.class);
//                            viewAllList.add(viewAll);
//                            viewAllAdapter.notifyDataSetChanged();
//
//                        }
//                    }else{
//                        Toast.makeText(viewAllActivity.this,"Error"+task.getException(), Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
//            reference.child("0").child("allMenu").child("0").child("category").equalTo("category","soup").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
//                @Override
//                public void onComplete(@NonNull Task<DataSnapshot> task) {
//                    if( task.isSuccessful()) {
//                        for (DataSnapshot document : task.getResult().getChildren()) {
//                            viewAll viewAll = document.getValue(viewAll.class);
//                            viewAllList.add(viewAll);
//                            viewAllAdapter.notifyDataSetChanged();
//
//                        }
//                    }else{
//                        Toast.makeText(viewAllActivity.this,"Error"+task.getException(), Toast.LENGTH_SHORT).show();
//                    }
//
//                }
//            });
        }

        if ( category != null && category.equalsIgnoreCase("soup")){
            reference.child("0").child("allMenu").child("0").equalTo("category","soup").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {

                    for (DataSnapshot document : task.getResult().getChildren()){
                        viewAll viewAll = document.getValue(viewAll.class);
                        viewAllList.add(viewAll);
                        viewAllAdapter.notifyDataSetChanged();

                    }

                }
            });
        }

        if ( category != null && category.equalsIgnoreCase("hamburger")){
            reference.child("0").child("allMenu").equalTo("category","hamburger").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {

                    for (DataSnapshot document : task.getResult().getChildren()){
                        viewAll viewAll = document.getValue(viewAll.class);
                        viewAllList.add(viewAll);
                        viewAllAdapter.notifyDataSetChanged();

                    }

                }
            });
        }

        if ( category != null && category.equalsIgnoreCase("drink")){
            reference.child("0").child("allMenu").child("0").equalTo("category","drink").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {

                    for (DataSnapshot document : task.getResult().getChildren()){
                        viewAll viewAll = document.getValue(viewAll.class);
                        viewAllList.add(viewAll);
                        viewAllAdapter.notifyDataSetChanged();

                    }

                }
            });
        }

        if ( category != null && category.equalsIgnoreCase("healthy")){
            reference.child("0").child("allMenu").child("0").equalTo("category","healthy").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {

                    for (DataSnapshot document : task.getResult().getChildren()){
                        viewAll viewAll = document.getValue(viewAll.class);
                        viewAllList.add(viewAll);
                        viewAllAdapter.notifyDataSetChanged();

                    }

                }
            });
        }

        if ( category != null && category.equalsIgnoreCase("fish")){
            reference.child("0").child("allMenu").child("0").equalTo("category","fish").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {

                    for (DataSnapshot document : task.getResult().getChildren()){
                        viewAll viewAll = document.getValue(viewAll.class);
                        viewAllList.add(viewAll);
                        viewAllAdapter.notifyDataSetChanged();

                    }

                }
            });
        }

    }
}