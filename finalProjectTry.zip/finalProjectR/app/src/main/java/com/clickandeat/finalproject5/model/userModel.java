package com.clickandeat.finalproject5.model;

import android.widget.EditText;

public class userModel {

    String name, email, password ,address ,profileImg;
    int phone;

    public userModel(String email, int phone, String name, String password, String address) {
        this.name = name;
        this.address=address;
        this.email=email;
        this.password= password;
        this.phone = phone ;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getProfileImg() {
        return profileImg;
    }

    public void setProfileImg(String profileImg) {
        this.profileImg = profileImg;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }




}
