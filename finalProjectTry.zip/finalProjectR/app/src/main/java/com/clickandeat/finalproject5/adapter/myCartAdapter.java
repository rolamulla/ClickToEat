package com.clickandeat.finalproject5.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.clickandeat.finalproject5.FoodDetails;
import com.clickandeat.finalproject5.R;
import com.clickandeat.finalproject5.model.myCartModel;

import java.util.List;

public class myCartAdapter extends RecyclerView.Adapter<myCartAdapter.ViewHolder> {

    Context context;
    List<myCartModel> cartModelList;
    int totalTxt = 0;



    public myCartAdapter(Context context, List<myCartModel> cartModelList) {
        this.context = context;
        this.cartModelList = cartModelList;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_item_in_cart, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.nameMana.setText(cartModelList.get(position).getName());
        holder.quntity.setText(cartModelList.get(position).getQuantity());
        holder.price.setText(cartModelList.get(position).getPrice());
        holder.totalPrice.setText(String.valueOf(cartModelList.get(position).getTotalPrice()));
        holder.resturantName.setText(cartModelList.get(position).getResturant());


        Glide.with(context).load(cartModelList.get(position).getImage()).into(holder.picCard);

        //pass total amount to my Cart

        totalTxt = totalTxt + cartModelList.get(position).getTotalPrice();
        Intent intent = new Intent("Total");
        intent.putExtra("Total",totalTxt);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

    }

    @Override
    public int getItemCount() {
        return cartModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView picCard;
        TextView nameMana, quntity, price,totalPrice, resturantName ;
        Button addItem , removeItem ;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            nameMana = itemView.findViewById(R.id.nameMana);
            quntity = itemView.findViewById(R.id.quntity);
            price = itemView.findViewById(R.id.price);
            totalPrice = itemView.findViewById(R.id.totalPrice);
            resturantName = itemView.findViewById(R.id.resturantName);
            picCard = itemView.findViewById(R.id.picCard);
            addItem = itemView.findViewById(R.id.plusCardBtn);
            removeItem = itemView.findViewById(R.id.minusCardBtn);



        }
    }
}
