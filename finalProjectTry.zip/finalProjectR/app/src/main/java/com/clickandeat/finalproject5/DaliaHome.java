package com.clickandeat.finalproject5;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.clickandeat.finalproject5.Adapter2.RestaurantAdapterDalia;
import com.clickandeat.finalproject5.Interface.RestaurantClickListener;
import com.clickandeat.finalproject5.adapter.AllMenuAdapter;
import com.clickandeat.finalproject5.adapter.PopularAdapter;
import com.clickandeat.finalproject5.adapter.RecommendedAdapter;
import com.clickandeat.finalproject5.model.AllMenu;
import com.clickandeat.finalproject5.model.Popular;
import com.clickandeat.finalproject5.model.Recommended;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class DaliaHome extends AppCompatActivity {

    PopularAdapter popularAdapter;
    RecommendedAdapter recommendedAdapter ;
    List<Popular> popularLst=new ArrayList<>();
    List<Recommended> recommendedLst=new ArrayList<>();
    ImageView backImg;

    AllMenuAdapter allMenuAdapter;
    RestaurantAdapterDalia restaurantAdapterDalia;
    List<AllMenu> allMenuLst=new ArrayList<>();

    /////Search view
    EditText search_box;
    private List<AllMenu> viewAllMenu;
    private RecyclerView recyclerViewSearch ;
    private AllMenuAdapter viewAllAdapter;

    FirebaseFirestore db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        String name = getIntent().getStringExtra("name");
        Log.w("FODA", "name=" + name +" From Second home!!!!");
        FooterD.getInstance().initFooter(this);

//        menuBtn = findViewById(R.id.menuBtn);

        RecyclerView popularRecyclerView = findViewById(R.id.popular_recycler);
        RecyclerView recommendedRecyclerView = findViewById(R.id.recommended_recycler);
        RecyclerView resListRecyclerView = findViewById(R.id.resListRecyclerView);


        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);

        popularRecyclerView.setLayoutManager(linearLayoutManager);
        popularAdapter = new PopularAdapter(this, popularLst);
        popularRecyclerView.setAdapter(popularAdapter);

        LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(this );
        linearLayoutManager1.setOrientation(LinearLayoutManager.HORIZONTAL);

        recommendedRecyclerView.setLayoutManager(linearLayoutManager1);
        recommendedAdapter = new RecommendedAdapter(this, recommendedLst);
        recommendedRecyclerView.setAdapter(recommendedAdapter);


        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(this );
        linearLayoutManager2.setOrientation(LinearLayoutManager.VERTICAL);

        RecyclerView allMenuRecyclerView = findViewById(R.id.all_menu_recycler);

        allMenuRecyclerView.setLayoutManager(linearLayoutManager2);
        allMenuAdapter = new AllMenuAdapter(this, allMenuLst);
        allMenuRecyclerView.setAdapter(allMenuAdapter);

        LinearLayoutManager linearLayoutManager3 = new LinearLayoutManager(this );
        linearLayoutManager3.setOrientation(LinearLayoutManager.HORIZONTAL);

        resListRecyclerView.setLayoutManager(linearLayoutManager3);

        RestaurantClickListener listener = new RestaurantClickListener() {
            @Override
            public void onRestaurantClick(String name) {
                DaliaHome.this.onRestaurantClick(name);
            }
        };

        restaurantAdapterDalia = new RestaurantAdapterDalia(this, listener);
        resListRecyclerView.setAdapter(restaurantAdapterDalia);


        String email = FirebaseAuth.getInstance().getCurrentUser().getEmail().replace(".", "_");

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();

        reference.child("1").child("allMenu").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds:dataSnapshot.getChildren()) {
                    AllMenu p=ds.getValue(AllMenu.class);
                    //Toast.makeText(YarkaHome.this,p.getName(),Toast.LENGTH_LONG).show();
                    allMenuLst.add(p);
                }
                allMenuAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });


        reference.child("1").child("popular").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds:dataSnapshot.getChildren()) {
                    Popular p=ds.getValue(Popular.class);
                    popularLst.add(p);
                }
                popularAdapter.notifyDataSetChanged();
            }

            //   DatabaseReference reference = FirebaseDatabase.getInstance().getReference();

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });


        reference.child("1").child("recommended").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds:dataSnapshot.getChildren()) {
                    Recommended p=ds.getValue(Recommended.class);
                    recommendedLst.add(p);
                }
                recommendedAdapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

        backImg = findViewById(R.id.backImg);
        backImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DaliaHome.super.onBackPressed();
            }
        });


        //search
        //search_box = findViewById(R.id.search_rec);
//        recyclerViewSearch.setLayoutManager((new LinearLayoutManager(getApplicationContext())));
//        recyclerViewSearch.setAdapter(viewAllAdapter);
//        recyclerViewSearch.setHasFixedSize(true);
//        search_box.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable s) {
//
//                if (s.toString().isEmpty()){
//                    viewAllMenu.clear();
//                    viewAllAdapter.notifyDataSetChanged();
//                }else{
//                    searchProduct(s.toString());
//                }
//            }
//        });
//
//    }
//
//    private void searchProduct(String type) {
//
//        if( !type.isEmpty()){
//        //    db.collection();
//        }
    }
    public void onRestaurantClick(String name){
        Log.w("FODA", "clicked on restaurant name="+name);
        Intent intent = new Intent(this, FinalPageDalia.class);
        intent.putExtra("name", name);
        startActivity(intent);
    }
}