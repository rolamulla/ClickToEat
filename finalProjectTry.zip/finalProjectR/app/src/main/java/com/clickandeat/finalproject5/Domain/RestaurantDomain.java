package com.clickandeat.finalproject5.Domain;

import android.graphics.drawable.Drawable;

public class RestaurantDomain {
    private String title;
    private Drawable pic;

    public RestaurantDomain(){}
    public RestaurantDomain(String title, Drawable pic) {
        this.title = title;
        this.pic = pic;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Drawable getPic() {
        return pic;
    }

    public void setPic(Drawable pic) {
        this.pic = pic;
    }
}
