package com.clickandeat.finalproject5.Interface;

public interface RestaurantClickListener {
    void onRestaurantClick(String name);
}
