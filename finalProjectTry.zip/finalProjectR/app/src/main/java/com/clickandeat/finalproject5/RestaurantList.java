package com.clickandeat.finalproject5;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class RestaurantList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_list);
    }
}