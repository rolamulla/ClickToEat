package com.clickandeat.finalproject5;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class itemInCart extends AppCompatActivity {

    ImageView imageView;
    TextView itemName, itemPrice;
    String name, price, image;
    int thePrice;
    TextView quantity;
    int totalQuantity = 1, totalPrice = 0;
    ImageView addItem1, removeItem1;


    private FirebaseFirestore firestore;
    FirebaseAuth auth;


    private Context context;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_in_cart);

        Intent intent = getIntent();

        name = intent.getStringExtra("name");
        price = intent.getStringExtra("price");
        image = intent.getStringExtra("image");

        imageView = findViewById(R.id.imageItem);
        itemName = findViewById(R.id.name);
        itemPrice = findViewById(R.id.price);


        quantity = findViewById(R.id.quntity);
        addItem1 = findViewById(R.id.plusCardBtn);
        removeItem1 = findViewById(R.id.minusCardBtn);



        firestore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();


        Glide.with(getApplicationContext()).load(image).into(imageView);
        itemName.setText(name);
        itemPrice.setText(price);
        thePrice = Integer.parseInt(itemPrice.getText().toString());

        addItem1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (totalQuantity < 10) {
                    totalQuantity++;
                    quantity.setText(String.valueOf(totalQuantity));
                    totalPrice = thePrice * totalQuantity;
                }
            }
        });

        removeItem1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (totalQuantity > 1) {
                    thePrice = Integer.parseInt(itemPrice.getText().toString());
                    totalQuantity--;
                    quantity.setText(String.valueOf(totalQuantity));
                    totalPrice = thePrice * totalQuantity;

                }

            }
        });



    }
}